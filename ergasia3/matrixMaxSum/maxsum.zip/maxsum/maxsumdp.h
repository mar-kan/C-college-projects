//Kanellaki Maria Anna - 1115201400060


#ifndef MAXSUMDP_H
#define MAXSUMDP_H

int maxsumdp(int, int, int**, int**);
void solve(int, int, int **);
int max(int, int, int);

#endif