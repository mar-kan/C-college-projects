//Kanellaki Maria Anna - 1115201400060


#ifndef MAXSUMMEM_H
#define MAXSUMMEM_H

int maxsummem(int, int, int, int**, int**);
void solve(int, int, int **);
int max(int, int, int);

#endif
