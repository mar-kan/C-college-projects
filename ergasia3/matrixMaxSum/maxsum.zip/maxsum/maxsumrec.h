//Kanellaki Maria Anna - 1115201400060


#ifndef MAXSUMREC_H
#define MAXSUMREC_H

int maxsumrec(int, int, int, int**);
void solve(int, int, int **);
int max(int, int, int);

#endif
