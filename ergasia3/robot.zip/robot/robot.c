#include <stdio.h>
#include <stdlib.h>
#include "robotlibrary.h"
int main(void){
	int **A,n,m,i,j,a;
	void solve(int,int,int**);
	scanf("%d %d",&n,&m);								   //reads matrix dimensions
	A=malloc(n*sizeof(int*));  							 //dynamic memory allocation
	if(A==NULL){
		printf("ERROR");
		return -1;
	}
	for(i=0; i<n; i++){
		A[i]=malloc(m*sizeof(int));
		if(A[i]==NULL){
			printf("ERROR");
			return -1;
		}
	}
	for(i=0; i<n; i++){
		for(j=0; j<m; j++){
			a=getchar();							      //reads matrix elements
			if(a=='C') A[i][j]=1;					    //if there is a coin(C) A[i][j]=1
			else if(a=='.') A[i][j]=0;				   //if there is no coin(.) A[i][j]=0
			else j--;		//if it reads any other character it reads again until a='C' or a='.'
		}
	}
	solve(n,m,A);
	for(i=0; i<n; i++)								      //free allocated memory
		free(A[i]);
	free(A);
	return 0;
}
void solve(int n,int m,int **A){
	#if defined(PUREREC)
		int C;
		printf("Running pureRecursive\n");
		C=pureRecursive(n-1,m-1,A); 													       //calculates max coins
		printf("Maximum number of coins to pick up is: %d\n",C);
	#elif defined(MATRREC)
		int **max,i,j;
		max=malloc(n*sizeof(int*));											      //allocate memory for the second matrix
		if(max==NULL){
			printf("ERROR");
			return;
		}
		for(i=0; i<n; i++){
			max[i]=malloc(m*sizeof(int));
			if(max[i]==NULL){
				printf("ERROR");
				return;
			}
		}
		for(i=0; i<n; i++){
			for(j=0; j<m; j++){
				max[i][j]=-1;
			}
		}
		printf("Running matrRecursive\n");
		max[n-1][m-1]=matrRecursive(n-1,m-1,A,max);	//matreRecursice calculates the maximum number of coins a robot can collect when it is in cell (n-1,m-1)
		printf("Path is: ");
		path(n-1,m-1,A,max);	
		printf("Picked up %d coins\n",max[n-1][m-1]);
		for(i=0; i<n; i++)														    //free allocated memory
			free(max[i]);
		free(max);
	#elif defined(ITERDP)
		int **max,i,j;
		max=malloc(n*sizeof(int*));											    //allocate memory for the second matrix
		if(max==NULL){
			printf("ERROR");
			return;
		}
		for(i=0; i<n; i++){
			max[i]=malloc(m*sizeof(int));
			if(max[i]==NULL){
				printf("ERROR");
				return;
			}
		}
		for(i=0; i<n; i++){
			for(j=0; j<m; j++){
				max[i][j]=-1;
			}
		}
		printf("Running iterativeDP\n");
		for(j=0; j<m; j++){
			for(i=0; i<n; i++){
				max[i][j]=iterativeDP(i,j,A,max);	  //iterativeDP calculates the maximum number of coins a robot can collect when it is in cell (i,j)
			}
		}
		printf("Path is: ");
		path(n-1,m-1,A,max);	
		printf("Picked up %d coins\n",max[n-1][m-1]);
		for(i=0; i<n; i++)														    //free allocated memory
			free(max[i]);
		free(max);
	#elif defined(MINROBOTS)
		minrobots(n,m,A);					    //minrobots prints the minimun number of robots needed to collect all the coins and their paths
	#endif
}
