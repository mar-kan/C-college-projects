#include <stdio.h>
#if defined(PUREREC)
int pureRecursive(int n,int m,int **A){
	if(n==0 && m==0){												    //if n=0 and m=0 the number of coins is A[i][j]
		return A[n][m]; 
	}
	else if(n==0){					      //if n=0 and m!=0 the maximum number of coins is previous cell's max plus A[i][j](previous cell is A[n][m-1])
		return A[n][m]+pureRecursive(n,m-1,A);	
	}
	else if(m==0){					      //if n!=0 and m=0 the maximum number of coins is previous cell's max plus A[i][j](previous cell is A[n-1][m])
		return A[n][m]+pureRecursive(n-1,m,A);
	}
	else{												      //maximum number of coins is previous cell's max plus A[i][j]
		if(pureRecursive(n,m-1,A)>=pureRecursive(n-1,m,A))						//previous cell is the one with the maximum number of coins		
			return A[n][m]+pureRecursive(n,m-1,A);
		else
			return A[n][m]+pureRecursive(n-1,m,A);
		
	}
}
#elif defined(MATRREC)
int matrRecursive(int n,int m,int **A,int **max){
	if(n==0 && m==0){										      //if n=0 and m=0 the number of coins is A[i][j]
		max[n][m]=A[n][m];
	}
	else if(n==0){				//if n=0 and m!=0 the maximum number of coins is previous cell's max plus A[i][j](previous cell is A[n][m-1])
		if(max[n][m-1]<0) 											      //max[n][m-1] is not calculated
			max[n][m]=A[n][m]+matrRecursive(n,m-1,A,max);	
		else 
			max[n][m]=A[n][m]+max[n][m-1];		
		
	}
	else if(m==0){				//if n!=0 and m=0 the maximum number of coins is previous cell's max plus A[i][j](previous cell is A[n-1][m])
		if(max[n-1][m]<0)									         	      //max[n][m-1] is not calculated
			max[n][m]=A[n][m]+matrRecursive(n-1,m,A,max);
		else
			max[n][m]=A[n][m]+max[n-1][m];
		
	}
	else{											 //maximum number of coins is previous cell's max plus A[i][j]
		if(max[n][m-1]<0 && max[n-1][m]<0){								  //calculates max[n][m-1]<0 and max[n-1][m]<0
			if(matrRecursive(n,m-1,A,max)>=matrRecursive(n-1,m,A,max))
				max[n][m]=A[n][m]+matrRecursive(n,m-1,A,max);					       //max[n][m] is the largest plus A[n][m]
			else 
				max[n][m]=A[n][m]+matrRecursive(n-1,m,A,max);
		}
		else if(max[n][m-1]<0 && max[n-1][m]>=0){					//calculates max[n][m-1]<0 max[n-1][m]<0 is already calculated
			if(matrRecursive(n,m-1,A,max)>=max[n-1][m])						       //max[n][m] is the largest plus A[n][m]
				max[n][m]=A[n][m]+matrRecursive(n,m-1,A,max);
			else
				max[n][m]=A[n][m]+max[n-1][m];
		}
		else if(max[n][m-1]>=0 && max[n-1][m]<0){					  //calculates max[n-1][m]<0 max[n][m]<0 is already calculated
			if(matrRecursive(n-1,m,A,max)>=max[n][m-1])						       //max[n][m] is the largest plus A[n][m]
				max[n][m]=A[n][m]+matrRecursive(n-1,m,A,max);
			else 
				max[n][m]=A[n][m]+max[n][m-1];
		}
		else{				
			if(max[n-1][m]>=max[n][m-1])								       //max[n][m] is the largest plus A[n][m]
				max[n][m]=A[n][m]+max[n-1][m];
			else
				max[n][m]=A[n][m]+max[n][m-1];
			
		}	
	}
	return max[n][m];	
}
#elif defined(ITERDP)
int iterativeDP(int n,int m,int **A,int **max){
	if(n==0 && m==0){									//if n=0 and m=0 the number of coins is A[i][j]
		return A[n][m];
	}
	else if(n==0){		  //if n=0 and m!=0 the maximum number of coins is previous cell's max plus A[i][j](previous cell is A[n][m-1])
		return A[n][m]+max[n][m-1];		
		
	}
	else if(m==0){		  //if n!=0 and m=0 the maximum number of coins is previous cell's max plus A[i][j](previous cell is A[n-1][m])
		return A[n][m]+max[n-1][m];
		
	}
	else{									  //maximum number of coins is previous cell's max plus A[i][j]
		if(max[n-1][m]>=max[n][m-1])							//previous cell is the one with the largest max
			return A[n][m]+max[n-1][m];
		else
			return A[n][m]+max[n][m-1];
	}
}
#elif defined(MINROBOTS)
void minrobots(int n,int m,int **A){
	int i,j,totalcoins=0,robots=0,x,flag,c=0,robotcoins;
	char ch;
	for(i=0; i<n; i++){										    //counts the total numbers of coins
		for(j=0; j<m; j++){
			if(A[i][j]==1)
				totalcoins++;
		}
	}
	while(totalcoins!=0){								   //it stops when the robots have picked all the coins
		robots++;											  //counts the number of robots 
		robotcoins=0;
		printf("Robot %d:",robots);
		i=0;
		j=0;
		while(i<n && j<m){ 
			if(A[i][j]==1){
				robotcoins++;					       	       //counts the number of coins this robot picks up
				A[i][j]=0;					  //when it picks up a coin the coin is removed from the matrix 
				ch='C';
			}
			else ch='.';
			printf("%c(%d,%d)/%d-->",ch,i+1,j+1,robotcoins);			
			if(i==n-1) j++;
			else if(j==m-1) i++;
			else{
			flag=0;
				for(x=i+1; x<n; x++){ 				   //flag=1 if there are coins that are down in the same columne
					if(A[x][j]==1){					    //search until column's end or until you find a coin
						flag=1;
						break;	
					}
				}
			if(flag==1) i++;					   //if there are coins down in the same columne robot goes down
			else j++;										//if there are not it goes right
			}
		}
		printf("Picked up %d coins\n",robotcoins);
		c=c+robotcoins;							     //c is the number of coins the robots have collected so far
		totalcoins=totalcoins-robotcoins;				//total numbers of coins reduces everytime a robot pics up coins
	}
	printf("%d robots picked up %d coin(s)\n",robots,c);
}
#endif
#if defined(MATRREC) || defined(ITERDP)
void path(int n,int m,int **A,int **max){
	char x;
	if(n==0 && m==0){		
		if(A[n][m]==1) x='C';
		else x='.';
		printf("%c(%d,%d)/%d-->",x,n+1,m+1,max[n][m]);
		return;
	}
	if(n==0){
		path(n,m-1,A,max);										      //if n=0 the previous cell of the path is (n,m-1)
		
	}
	else if(m==0){
		path(n-1,m,A,max);										      //if m=0 the previous cell of the path is (n-1,m)
		
	}
	else{
		if(max[n-1][m]>max[n][m-1]) path(n-1,m,A,max);				     //the previous cell of the path is the one that has the largest max number
		else path(n,m-1,A,max);
		
	}
	if(A[n][m]==1) x='C';
	else x='.';
	printf("%c(%d,%d)/%d-->",x,n+1,m+1,max[n][m]);	//prints the content of the cell,the coordinates of the cell and the number of coins the robot has taken so far
	return;
}
#endif
