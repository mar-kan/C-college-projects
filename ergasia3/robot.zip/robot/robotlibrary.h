int purerecursive(int,int,int**);
int matrrecursive(int,int,int**,int**);
int iterativeDP(int,int,int**,int**);
void path(int,int,int**,int**);
void minrobots(int,int,int**);
